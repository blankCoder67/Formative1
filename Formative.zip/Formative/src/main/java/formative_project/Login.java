package formative_project;

public class Login {

    private final String firstName;
    private final String lastName;
    private final String userName;
    private final String password;
    private final String cellPhoneNumber;

    public Login(String firstName, String lastName, String userName, String password, String cellPhoneNumber) {
        this.firstName = firstName;
        this.lastName = lastName; 
        this.userName = userName;
        this.password = password;
        this.cellPhoneNumber = cellPhoneNumber; // I included a first name and alst name in my string because i thought it would be good to have the users first and last name stored in the system when they register, but it is not nessassary 
    }

    public boolean checkUserName() {
        return userName.contains("_") && userName.length() <= 5; // This checks if the username contains an underscore and is no more than five characters in length
    }

    public boolean checkPasswordComplexity() {
        return password.length() >= 8
                && password.matches(".*[A-Z].*") // This checks if the password contains at least one uppercase letter
                && password.matches(".*[0-9].*") // This checks if the password contains at least one number
                && password.matches(".*[^a-zA-Z0-9].*"); // This checks if the password contains at least one special character (not a letter or number)
    }

    public boolean checkCellPhoneNumber() {
        return cellPhoneNumber.matches("^\\+27\\d{9}$");
    }

    public String registerUser() {
        if (!checkUserName()) {
            return "Username is not correctly formatted;please ensure that your username contains an underscore and is no more than five characters in length";
        }

        if (!checkPasswordComplexity()) {
            return "password is not correctly formatted; please ensure that the password contains atleast 8 characters, a capital letter, a number, and a special character.";
        }

        if (!checkCellPhoneNumber()) {
            return "Cell phone number incorrectly formatted or does not contain intenational code.";
        }

        return "User has been registered succesfully.";
    }

    public boolean loginUser(String loginUserName, String loginPassword) {
        return userName.equals(loginUserName) && password.equals(loginPassword);
    }

    public String returnLoginStatus(boolean loginStatus) {  // This method will return a welcome message if the login was successful and an error message if the login was unsuccessful
        if (loginStatus) {
            return "Welcome " + firstName + ", " + lastName + " it is great to see you again.";
        }

        return "Username or password incorret, please try again."; // This will return an error message if the login was unsuccessful
    }
}
