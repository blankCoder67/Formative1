/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package formative_project;

import java.util.Scanner;

/**
 *
 * @author rosebank
 */

public class Formative { // this class us used to ask the user for their input

    public static void main(String[] args) {
        try (Scanner input = new Scanner(System.in)) {    //In my research i have found that the scanner s used to read keybaord inputs hence why i included it in my code.
            System.out.println("Enter first name:");
            String firstName = input.nextLine();   // This line will ask the user for their first name

            System.out.println("Enter last name:");
            String lastName = input.nextLine();       //This asks for the last name

            System.out.println("Enter username:"); // This asks for the username
            String username = input.nextLine();
            System.out.println("Enter Password:"); // This asks for the password
            String password = input.nextLine();

            System.out.println("Enter cellpohne number:"); // This asks for the cellphone number
            String cell = input.nextLine();

            Login login = new Login(firstName, lastName, username, password, cell);

            if (login.checkUserName()) {
                System.out.println("Username successfully captured"); // This will print if the username is correct
            } else {
                System.out.println("Username is not correctly formatted;please ensure that your username contains an underscore and is no more than five characters in length"); // This will print if the username is wrong
            }
                // I tried to ensure that if the username is not correct, the user wont be able to proceed to entering the password
            if (login.checkPasswordComplexity()) {
                System.out.println("Password captured sccessfully"); // This will print if the password is correct
            } else {
                System.out.println("password is not correctly formatted; please ensure that the password contains atleast 8 characters, a capital letter, a number, and a special character."); // This will print if the password is wrong
            }

            if (login.checkCellPhoneNumber()) {
                System.out.println("Cell phone number successfully added"); // This will print if the cellphone number is correct
            } else {
                System.out.println("Cell phone number incorrectly formatted or does not contain intenational code.");
            }

            System.out.println(login.registerUser()); // This will print if the user has been registered successfully or if there was an error in the registration process

            if (login.checkUserName() && login.checkPasswordComplexity() && login.checkCellPhoneNumber()) {
                System.out.println("Login to your account");
                System.out.println("Enter username:");  // This will ask the user to enter their username to login
                String loginUsername = input.nextLine(); // This will store the username that the user has entered to login
                System.out.println("Enter password:"); // This will ask the user to enter their password to login
                String loginPassword = input.nextLine(); // This will store the password that the user has entered to login

                boolean loginStatus = login.loginUser(loginUsername, loginPassword); // This will check if the username and password entered by the user to login are correct and will return true if they are correct and false if they are wrong
                System.out.println(login.returnLoginStatus(loginStatus));  // This will print a welcome message if the login was successful and an error message if the login was unsuccessful
            }
        }
    }
}
