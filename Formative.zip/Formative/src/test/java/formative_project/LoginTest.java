package formative_project;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class LoginTest {

    @Test
    void usernameCorrect() {
        Login l = new Login("Shival","Salikram","Shi_1","Ch&8sec@ke99!","+27838968976");
        assertTrue(l.checkUserName());
    }

    @Test
    void usernameWrong() { // if the username is not correctly formatted, the user will not be able to register and will receive an error message explaining what theyre did wrong in the registration process
        Login l = new Login("Shival","Salikram","Shi_123","Ch&8sec@ke99!","+27838968976");
        assertFalse(l.checkUserName());
        assertEquals("Username is not correctly formatted;please ensure that your username contains an underscore and is no more than five characters in length", l.registerUser());
    }

    @Test
    void passwordFine() { //  if the password is correctly formatted, the user will be able to register and will receive a message confirming that they have been registered successfully
        Login l = new Login("Shival","Salikram","Shi_1","Ch&8sec@ke99!","+27838968976");
        assertTrue(l.checkPasswordComplexity());
    }

    @Test
    void passwordWrong() { //  if the password is not correctly formatted, the user will not be able to register and will receive an error message explaining what theyre did wrong in the registration process
        Login l = new Login("Shival","Salikram","Shi_1","password","+27838968976");
        assertFalse(l.checkPasswordComplexity());
        assertEquals("password is not correctly formatted; please ensure that the password contains atleast 8 characters, a capital letter, a number, and a special character.", l.registerUser());
    }

    @Test
    void cellOkay() {
        Login l = new Login("Shival","Salikram","Shi_1","Ch&8sec@ke99!","+27838968976");
        assertTrue(l.checkCellPhoneNumber());
    }

    @Test
    void cellWrong() { //  if the cellphone number is not correctly formatted, the user will not be able to register and will receive an error message explaining what theyre did wrong in the registration process
        Login l = new Login("Shival","Salikram","Shi_1","Ch&8sec@ke99!","08966553");
        assertFalse(l.checkCellPhoneNumber());
        assertEquals("Cell phone number incorrectly formatted or does not contain intenational code.", l.registerUser());
    }

    @Test
    void registerWorks() {
        Login l = new Login("Shival","Salikram","Shi_1","Ch&8sec@ke99!","+27838968976");
        assertEquals("User has been registered succesfully.", l.registerUser());
    }

    @Test
    void loginOk() {
        Login l = new Login("Shival","Salikram","Shi_1","Ch&8sec@ke99!","+27838968976");
        assertTrue(l.loginUser("Shi_1","Ch&8sec@ke99!"));
    }

    @Test
    void loginFail() {
        Login l = new Login("Shival","Salikram","Shi_1","Ch&8sec@ke99!","+27838968976");
        assertFalse(l.loginUser("wrong","wrong"));
    }

    @Test
    void returnStatusOk() {
        Login l = new Login("Shival","Salikram","Shi_1","Ch&8sec@ke99!","+27838968976");
        assertEquals("Welcome Shival, Salikram it is great to see you again.", l.returnLoginStatus(true));
    }

    @Test
    void returnStatusFail() {
        Login l = new Login("Shival","Salikram","Shi_1","Ch&8sec@ke99!","+27838968976");
        assertEquals("Username or password incorret, please try again.", l.returnLoginStatus(false));
    }
}
